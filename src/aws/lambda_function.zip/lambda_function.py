# lambda function to be deployed


def lambda_handler(event, context):
    print(event)
    print("all done!")
